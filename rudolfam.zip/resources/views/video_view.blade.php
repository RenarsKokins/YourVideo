@extends('layouts.app')

@section('content')
<!-- <div class="container-fluid p-0 pt-lg-4 pl-lg-4 pr-lg-4"> -->
<div class="col-sm container-fluid p-0">
    <div class="row m-0">
        <div class="col-lg-8 p-0 theme-darker-base">
            <div>
                <video id="vid1" class="video-js vjs-big-play-centered" controlslist="nodownload" preload="auto" controls>
                    <source src="{{asset($path).'.m3u8'}}" type="application/x-mpegURL"/>
                    Your browser does not support the video tag. 
                </video>
            </div>
            <div class="pt-2 ml-2">
                <h4>{{$video->title}}</h4>
            </div>
            <div class="container-fluid">
                <div class="row">
                    <div class="col pl-2">
                        <p>{{$video->views." views, ".$video->created_at}}</p>
                    </div>
                    <div class="col pl-2">
                        <button class="video-liked btn float-right pt-0 pb-0 d-flex" id="dislike-block">
                            <svg class="mr-1" xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="gray" viewBox="0 0 16 16">
                            <path d="M6.956 14.534c.065.936.952 1.659 1.908 1.42l.261-.065a1.378 1.378 0 0 0 1.012-.965c.22-.816.533-2.512.062-4.51.136.02.285.037.443.051.713.065 1.669.071 2.516-.211.518-.173.994-.68 1.2-1.272a1.896 1.896 0 0 0-.234-1.734c.058-.118.103-.242.138-.362.077-.27.113-.568.113-.856 0-.29-.036-.586-.113-.857a2.094 2.094 0 0 0-.16-.403c.169-.387.107-.82-.003-1.149a3.162 3.162 0 0 0-.488-.9c.054-.153.076-.313.076-.465a1.86 1.86 0 0 0-.253-.912C13.1.757 12.437.28 11.5.28H8c-.605 0-1.07.08-1.466.217a4.823 4.823 0 0 0-.97.485l-.048.029c-.504.308-.999.61-2.068.723C2.682 1.815 2 2.434 2 3.279v4c0 .851.685 1.433 1.357 1.616.849.232 1.574.787 2.132 1.41.56.626.914 1.28 1.039 1.638.199.575.356 1.54.428 2.591z"/>
                            </svg>
                            <p id="dislike-text" class="m-0">{{$video->dislikes}}</p>
                        </button>
                        <button class="video-liked btn float-right pt-0 pb-0 d-flex" id="like">
                            <svg class="mr-1" xmlns="http://www.w3.org/2000/svg" width="20" height="20" fill="gray" viewBox="0 0 16 16">
                            <path d="M6.956 1.745C7.021.81 7.908.087 8.864.325l.261.066c.463.116.874.456 1.012.965.22.816.533 2.511.062 4.51a9.84 9.84 0 0 1 .443-.051c.713-.065 1.669-.072 2.516.21.518.173.994.681 1.2 1.273.184.532.16 1.162-.234 1.733.058.119.103.242.138.363.077.27.113.567.113.856 0 .289-.036.586-.113.856-.039.135-.09.273-.16.404.169.387.107.819-.003 1.148a3.163 3.163 0 0 1-.488.901c.054.152.076.312.076.465 0 .305-.089.625-.253.912C13.1 15.522 12.437 16 11.5 16H8c-.605 0-1.07-.081-1.466-.218a4.82 4.82 0 0 1-.97-.484l-.048-.03c-.504-.307-.999-.609-2.068-.722C2.682 14.464 2 13.846 2 13V9c0-.85.685-1.432 1.357-1.615.849-.232 1.574-.787 2.132-1.41.56-.627.914-1.28 1.039-1.639.199-.575.356-1.539.428-2.59z"/>
                            </svg>
                            <p id="like-text" class="m-0">{{$video->likes}}</p>
                        </button>
                    </div>
                </div>
            </div>
            <div class="d-flex flex-row ml-2 mr-2 mb-2">
                <p class="mb-auto mt-auto">Uploaded by: <b>{{$video->user->name}}</b></p>
                <button class="btn btn-primary p-0 ml-2 mt-auto mb-auto" id="follow-button">Follow</button>
            </div>
            <hr class="theme-lighter-base ml-2 mr-2 mt-0">
            <div class="ml-2 mr-2">
                <h5>Description</h5>
                @if ($video->description)
                <p>{{$video->description}}</p>
                @else
                <p>No description.</p>
                @endif
            </div>
            <hr class="theme-lighter-base ml-2 mr-2 mt-0">
            <div class="text-light ml-2 mr-2">
                <h5 class="mb-4">Comments</h5>
                @if (Auth::check())
                <form method="POST" class="comment-form" action="post-comment">
                    @csrf
                    <input name="video_id" type="hidden" value="{{$video->id}}">
                    <div class="form-group">
                        <label class="mb-0" for="description">Add your comment</label>
                        <button type="submit" class="float-right btn btn-primary mb-2">Submit</button>
                        <textarea class="form-control text-white theme-lighter-base" id="comment" placeholder="Your comment" name="comment" rows="3"></textarea>
                    </div>
                </form>
                @else
                <p>Register or log in to leave a comment.</p>
                @endif
                <button class="btn btn-primary mb-2 p-0" type="button" data-toggle="collapse" data-target=".comments-section" aria-controls="commentsSection" aria-expanded="false" aria-label="{{ __('Toggle comments section') }}">Show comments</button>
                <hr class="theme-lighter-base mt-0">
                <div class="comments-section collapse">
                </div>
            </div>
        </div>
        <div class="col-lg-4 mt-4">
            <div class="recommended-videos">
            </div>
        </div>
    </div>
</div>
@endsection